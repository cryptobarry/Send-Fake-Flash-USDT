<!!--------READ ME FILE-----------!!>

1, Open the send.html file.
2, Enter a valid USDT Address.
3, Enter the USDT Amount.
4, Select Main Network or Test Network.
5, Click on the send fake USDT button to send a flash/fake USDT transaction.



NOTE TO START SENDING FAKE/FLASH USDT TRANSACTION YOU MUST FIRST UNLOCK YOUR ACCOUNT TO GET A VALID AUTHENTICATION KEY..!!